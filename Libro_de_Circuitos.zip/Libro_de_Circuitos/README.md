# Libro de Circuitos: Diseño de Circuitos

**Universidad Nacional de Loja · Carrera de Computación · 2.º ciclo**
**Unidad 1: Análisis de lógica combinacional con diseño clásico**

Libro técnico de apoyo, redactado a partir de las diapositivas de clase. Cada semana contiene un marco teórico (`resumen.md`), problemas (`ejercicios.md`) y su resolución (`soluciones.md`).

## Contenido

| Semana | Tema | Resumen | Ejercicios | Soluciones |
|:------:|------|:-------:|:----------:|:----------:|
| 1 | Sistemas numéricos, códigos y compuertas lógicas | [Resumen](./semana-01/resumen.md) | [Ejercicios](./semana-01/ejercicios.md) | [Soluciones](./semana-01/soluciones.md) |
| 2 | Álgebra de Boole y formas canónicas | [Resumen](./semana-02/resumen.md) | [Ejercicios](./semana-02/ejercicios.md) | [Soluciones](./semana-02/soluciones.md) |
| 3 | Mapas de Karnaugh, condiciones indiferentes y universalidad NAND/NOR (Sesiones 1 y 2) | [Resumen](./semana-03/resumen.md) | [Ejercicios](./semana-03/ejercicios.md) | [Soluciones](./semana-03/soluciones.md) |
| 4 | Circuitos aritméticos | [Resumen](./semana-04/resumen.md) | [Ejercicios](./semana-04/ejercicios.md) | [Soluciones](./semana-04/soluciones.md) |

## Figuras

Las figuras se referencian como `./assets/nombre.png` dentro de la carpeta de cada semana. El listado de imágenes que debe colocarse en cada `assets/` está en `assets/README.md` de cada semana.

## Notación

- Complemento: $\overline{A}$ (equivalente a $A'$ en las diapositivas).
- Fórmulas en LaTeX, renderizadas por GitHub (`$...$` y `$$...$$`).
